<?php

namespace App\Models;

use OwenIt\Auditing\Models\Audit as BaseAudit;

class Audit extends BaseAudit
{
    // Puedes agregar métodos o relaciones si quieres, o dejarlo vacío
}
